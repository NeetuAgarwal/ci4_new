 var base_url= $("#base_url").val();
 var admin = $("#admin").val();
 var valid = {
			 

			ajaxError:function(jqXHR,exception) {
				var msg = '';
				if (jqXHR.status === 0) {
					msg = 'Not connect.\n Verify Network.';
				} else if (jqXHR.status == 404) {
					msg = 'Requested page not found. [404]';
				} else if (jqXHR.status == 500) {
					msg = 'Internal Server Error [500].';
				} else if (exception === 'parsererror') {
					msg = 'Requested JSON parse failed.';
				} else if (exception === 'timeout') {
					msg = 'Time out error.';
				} else if (exception === 'abort') {
					msg = 'Ajax request aborted.';
				} else {
					msg = 'Uncaught Error.\n' + jqXHR.responseText;
				}
				return msg;
			},
			
			phonenumber:function(inputtxt) {
				var phoneno = /^\d{10}$/;  
				return phoneno.test(inputtxt);
			},
			validPhone:function(inputtxt) {
				var phoneno = /^[0-9]\d{2,4}-\d{6,8}$/;  
				return phoneno.test(inputtxt);
			},
			validURL:function(inputtxt) {
				var re = /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g;
				return re.test(inputtxt);
			},
			validateEmail:function(email) {
				var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
				return re.test(email);
			},
			validFBurl:function(enteredURL) {
				var FBurl = /^(http|https)\:\/\/www.facebook.com\/.*/i;
				return FBurl.test(enteredURL);
			},
			validTwitterurl:function(enteredURL) {
				var twitterURL = /^(http|https)\:\/\/twitter.com\/.*/i;
				return twitterURL.test(enteredURL);
			},
			validYoutubeURL:function(enteredURL) {
				var youtubeURL = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|\?v=)([^#\&\?]*).*/;
				return youtubeURL.test(enteredURL);
			},
			validGPlusURL:function(enteredURL) {
				var gPlusURL = /\+[^/]+|\d{21}/;
				return gPlusURL.test(enteredURL);
			},
			validInstagramURL:function(enteredURL) {
				var instagramURL = /(?:(?:http|https):\/\/)?(?:www.)?(?:instagram.com|instagr.am)\/([A-Za-z0-9-_\.]+)/im;
				return instagramURL.test(enteredURL);
			},
			validateExtension:function(val,type) {
				if(type==1)
					var re = /(\.jpeg|\.jpg|\.png)$/i;
				else if(type==2)
					var re = /(\.jpeg|\.jpg|\.png\.pdf|\.doc|\.xml|\.docx|\.PDF|\.DOC|\.XML|\.DOCX|\.xls|\.xlsx)$/i;
				else if(type==3)
					var re = /(\.pdf|\.docx|\.PDF|\.DOC|\.DOCX)$/i;
				return re.test(val)
			},
			snackbar:function(msg) {
				$("#snackbar").html("<p class='alert alert-dark'>"+msg+"</p>").fadeIn('slow').delay(3000).fadeOut('slow');
			},
			snackbar2:function(msg) {
				 $("#snackbar").html(msg).fadeIn('slow');
			},
			snackbar_error:function(msg) {
				$("#snackbar-error").html(msg).fadeIn('slow').delay(3000).fadeOut('slow');
			},
			snackbar_success:function(msg) {
				$("#snackbar-success").html(msg).fadeIn('slow').delay(3000).fadeOut('slow');
			},
			error:function(msg) {
				return "<p class='alert alert-danger'><strong>Error : </strong> "+msg+"</p>";
			},
			success:function(msg) {
				return "<p class='alert alert-success'>"+msg+"</p>";
			},
			info:function(msg) {
				return "<p class='alert alert-info'>"+msg+"</p>";
			}
	};
	
 
 jQuery(function($) {
	"use strict";
	
	$(document).on('click', '.blockUnblock', function(e){
		var id = $(this).attr('id');
        var myArray = id.split('-');
		var table_id=myArray[3];
	
        $.ajax({
            type: "POST",
            url:  base_url + '/block-data-function',
            data: 'id=' + myArray[1]+"&table="+myArray[2]+"&table_id="+table_id+"&status_name="+myArray[4],
            success: function(data) 
            {	
		
				
				if(myArray[0]=='danger')
                {
                    $("#"+id).html('<button class="btn btn-outline-success btn-xs m-l-5" type="button" title="Inactivate">Inactivate</button>');
					$("#status_show"+myArray[1]).html('<badge class="badge badge-success">Active</badge>');
                   $("#"+id).attr('id','success-'+myArray[1]+'-'+myArray[2]+'-'+table_id+'-'+myArray[4]);
                }
                else
                {
					$("#"+id).html('<button class="btn btn-outline-danger btn-xs m-l-5" type="button" title="Activate">Activate</button>');
					$("#status_show"+myArray[1]).html('<badge class="badge badge-danger">Inactive</badge>');
					$("#"+id).attr('id','danger-'+myArray[1]+'-'+myArray[2]+'-'+table_id+'-'+myArray[4]);
                }
                $("#msg").html(data);
                $("#msg").fadeIn('slow').delay(5000).fadeOut('slow');
            },
			error: function (jqXHR, exception) {
					var msg = valid.ajaxError(jqXHR,exception);
					$("#msg").html(valid.error(msg)).fadeIn('slow').delay(5000).fadeOut('slow');
					
				}
        });
		
		e.preventDefault();	
    }); 
	$(document).on('submit','#loginFrm',function(e){
	var email=$("#email").val();
	var password = $("#password").val();
	
	if(email == "")
	{
		$("#error").html("<p class='alert alert-danger'>Please Enter email</p>").fadeIn('slow').delay(3000).fadeOut('slow');
	}
	else if(password == "")
	{
			$("#error").html("<p class='alert alert-danger'>Please Enter password</p>").fadeIn('slow').delay(3000).fadeOut('slow');
	}
	else
	{
		$.ajax({
			url: base_url + '/submit-login',
			type:'POST',
			data: new FormData(this),
			processData: false,
			contentType: false,
			dataType:"json",
			success:function (data)
			{
				if(data.status == "success"){
					$("#error").html(data.msg).fadeIn('slow').delay(3000).fadeOut('slow');
					var url = base_url + admin+"/dashboard";
					$(location).attr('href', url);
				}
				else
				{
					$("#error").html(data.msg).fadeIn('slow').delay(3000).fadeOut('slow');
				}
			},
		});
	}
	 
	e.preventDefault();
	});
	
	$(document).on('submit', '#categoryFrm', function(e){
	
		var cat_name = $("#cat_name").val();
		var display_order = $("#display_order").val();
		var page_title = $("#page_title").val();
		var description = $("#description").val();
		var keywords = $("#keywords").val();
		var remaining = $("#remaining").val();
		var open_graph = $("#open_graph").val();
		var cat_file = $("#category_img").val();
		var old_icon = $("#old_icon").val();
		
		if(cat_name == ''){
			$("#errormsg").html(valid.error('Please enter category name')).fadeIn('slow').delay(2500).fadeOut('slow');
		}else if(display_order == ''){
			$("#errormsg").html(valid.error('Please enter display order')).fadeIn('slow').delay(2500).fadeOut('slow');
		}else if(page_title == ''){
			$("#errormsg").html(valid.error('Please enter page title')).fadeIn('slow').delay(2500).fadeOut('slow');
		}else if(cat_file == '' && old_icon == ""){
			$("#errormsg").html(valid.error('Please enter category image')).fadeIn('slow').delay(2500).fadeOut('slow');
		}
		else
		{
			$("#submitBtn").attr("disabled",true);	   
			var changeBtn = $("#submitBtn").html();
			$("#submitBtn").html("Submitting..");
			$.ajax({
				type: "POST",
				url: base_url + "/submit-category",
				data: new FormData( this ),
				processData: false,
				contentType: false,
				dataType: "json",
				success: function (data) {
					if (data.status == 'success'){
						$("#errormsg").html(data.msg);
						$("#errormsg").fadeIn('slow').delay(5000).fadeOut('slow');
						$('#categoryFrm')[0].reset();
						$('#csrftoken').val(data.csrf);
						/* window.setTimeout(function(){$('#addbrandModal').modal('hide')}, 1000); */
						dataTable.ajax.reload();
					}
					else if (data.status == 'update'){
						$("#errormsg").html(data.msg);
						$("#errormsg").fadeIn('slow').delay(5000).fadeOut('slow');
						dataTable.ajax.reload();
					}
					else{
						$("#errormsg").html(data.msg);
						$("#errormsg").fadeIn('slow').delay(5000).fadeOut('slow');
					}
					$("#submitBtn").attr("disabled",false);
					$("#submitBtn").html(changeBtn);
				},
				error: function (jqXHR, exception) {
						var msg = valid.ajaxError(jqXHR,exception);
						$("#errormsg").html(valid.error(msg)).fadeIn('slow').delay(5000).fadeOut('slow');
						$("#submitBtn").attr("disabled",false);
						$("#submitBtn").html(changeBtn);
				}
			});
		}
		e.preventDefault();	
    });
	$(document).on('click', '.openPopUpAddCategory', function(e){
		var dataURL = $(this).attr('data-href');
		$('.cat_body').load(dataURL,function(){
			$('.cat_title').html('Add Category');
			$('#addcategoryModal').modal({show:true});
		});
	});
	$(document).on('click', '.openPopUpEditCategory', function(e){
		var dataURL = $(this).attr('data-href');
		$('.cat_body').load(dataURL,function(){
			$('.cat_title').html('Edit Category');
			$('#addcategoryModal').modal({show:true});
		});
	});
	$(document).on('click', '.openPopUpViewCategory', function(e){
		var dataURL = $(this).attr('data-href');
		$('.cat_view_body').load(dataURL,function(){
			$('#viewcategoryModal').modal({show:true});
		});
	});
	
 });
 
 function validateImageExtensionOther(val,id_name)
{
	if(id_name==1)
		var fileUpload = document.getElementById("category_icon");
	if(id_name==2)
		var fileUpload = document.getElementById("subcategory_icon");
	if(id_name==3)
		var fileUpload = document.getElementById("sub_subcategory_icon");
	if(id_name==4)
		var fileUpload = document.getElementById("child_sub_subcategory_icon");
	if(id_name==5)
		var fileUpload = document.getElementById("product_cover_image");



	if(!valid.validateExtension(val,1) && id_name==1) 
    {            
		valid.snackbar('Invalid file type (only .jpeg,.jpg,.png allowed)');
		$('#file').val('');
		$('#category_img').val('');
		return false;
    }else if(!valid.validateExtension(val,3) && id_name==3)
	{
		valid.snackbar('Invalid file type (only .Pdf,.doc,.docx allowed)');
		$('#attachment').val('');
		return false;
	}
 
        //Check whether HTML5 is supported.
       else if (typeof (fileUpload.files) != "undefined") {
            //Initiate the FileReader object.
            var reader = new FileReader();
            //Read the contents of Image File.
            reader.readAsDataURL(fileUpload.files[0]);
            reader.onload = function (e) {
                //Initiate the JavaScript Image object.
                var image = new Image();
 
   
                //Set the Base64 string return from FileReader as source.
                image.src = e.target.result;
                       
                //Validate the File Height and Width.
                image.onload = function () {
					var file = fileUpload.files[0];//get file   
					var sizeKB = file.size / 1024;
                    var height = this.height;
                    var width = this.width;
                    if (height > 256 || width > 256) {
						valid.snackbar('Height and Width must not exceed 256px.');
						$("#category_icon").val('');
						$("#subcategory_icon").val('');
						$("#sub_subcategory_icon").val('');
                        return false;
                    }
					
					if(sizeKB>30)
					{
						valid.snackbar('Icon size must not exceed 30Kb.');
						$("#category_icon").val('');
						$("#subcategory_icon").val('');
						$("#sub_subcategory_icon").val('');
                        return false;
					}
					
						$("#submitBtn").attr("disabled",false);
					
                    return true;
                };
 
            }
        }  
}	
