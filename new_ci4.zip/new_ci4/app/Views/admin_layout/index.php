<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Demo Admin</title>
    <!-- ================= Favicon ================== -->
    <!-- Standard -->
    <link rel="shortcut icon" href="http://placehold.it/64.png/000/fff">
    <!-- Retina iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="144x144" href="http://placehold.it/144.png/000/fff">
    <!-- Retina iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="114x114" href="http://placehold.it/114.png/000/fff">
    <!-- Standard iPad Touch Icon-->
    <link rel="apple-touch-icon" sizes="72x72" href="http://placehold.it/72.png/000/fff">
    <!-- Standard iPhone Touch Icon-->
    <link rel="apple-touch-icon" sizes="57x57" href="http://placehold.it/57.png/000/fff">
    <!-- Styles -->
    <link href="<?php echo base_url('public/assets/css/lib/calendar2/pignose.calendar.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('public/assets/css/lib/chartist/chartist.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('public/assets/css/lib/font-awesome.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('public/assets/css/lib/themify-icons.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('public/assets/css/lib/owl.carousel.min.css'); ?>" rel="stylesheet" />
    <link href="<?php echo base_url('public/assets/css/lib/owl.theme.default.min.css'); ?>" rel="stylesheet" />
    <link href="<?php echo base_url('public/assets/css/lib/weather-icons.css'); ?>" rel="stylesheet" />
    <link href="<?php echo base_url('public/assets/css/lib/menubar/sidebar.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('public/assets/css/lib/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('public/assets/css/lib/helper.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('public/assets/css/style.css'); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css" rel="stylesheet">
</head>

<body class="<?php if(isset($bg_color)) { echo $bg_color; } ?>">

<?php if(isset($header)) echo $header ;?>
	<?php if(isset($middle)) echo $middle ;?>
	<?php if(isset($footer)) echo $footer ;?>
	<input type="hidden" id="base_url" value="<?php echo base_url();?>">
	<input type="hidden" id="admin" value="<?php echo admin;?>">
	<input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>" />
	<div id="snackbar"></div>
	<div id="snackbar-error"></div>
	<div id="snackbar-success"></div>
</div>
	 
	
	


    <!-- jquery vendor -->
    <script src="<?php echo base_url('public/assets/js/lib/jquery.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/jquery.nanoscroller.min.js'); ?>"></script>
    <!-- nano scroller -->
    <script src="<?php echo base_url('public/assets/js/lib/menubar/sidebar.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/preloader/pace.min.js'); ?>"></script>
    <!-- sidebar -->

    <script src="<?php echo base_url('public/assets/js/lib/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/scripts.js'); ?>"></script>
    <!-- bootstrap -->

    <script src="<?php echo base_url('public/assets/js/lib/calendar-2/moment.latest.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/calendar-2/pignose.calendar.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/calendar-2/pignose.init.js'); ?>"></script>


    <script src="<?php echo base_url('public/assets/js/lib/weather/jquery.simpleWeather.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/weather/weather-init.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/circle-progress/circle-progress.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/circle-progress/circle-progress-init.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/chartist/chartist.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/sparklinechart/jquery.sparkline.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/sparklinechart/sparkline.init.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/owl-carousel/owl.carousel.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/lib/owl-carousel/owl.carousel-init.js'); ?>"></script>
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <!-- scripit init-->
    <script src="<?php echo base_url('public/assets/js/dashboard2.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/js/custom.js'); ?>"></script>
	
	<script>
		var dataTable = '';
		<?php if(isset($categoryListTableFlag) && $categoryListTableFlag == 1){ ?>
						dataTable = $('#categoryList').DataTable( {
							"processing": true,
							"serverSide": true,
							"order": [0,"desc"],
							"ajax":{"url":base_url+"/category-list-grid-data","type": "POST","dataType": "json"},
							"columns": [
										{ "data": "#" },
										{ "data": "category_name" },
										{ "data": "category_icon" },
										{ "data": "display_order" },
										{ "data": "insert_date" },
										{ "data": "display_status" },
										{ "data": null },						
								],
								columnDefs: [{
									targets: [-1], render: function (a, b, data, d) {
										 var action='';
												action += '<a title="View" href="javascript:void(0);" data-href="'+base_url+admin+'/view-category/'+data.category_id+'" class="openPopUpViewCategory"><button class="btn btn-outline-primary btn-xs m-l-5" type="button" title="view">View</button></a>';
											
											action += '<a title="Edit" href="javascript:void(0);" data-href="'+base_url+admin+'/edit-category/'+data.category_id+'" class="openPopUpEditCategory"><button class="btn btn-outline-primary btn-xs m-l-5" type="button" title="edit">Edit</button></a>';
										 if (data.status == 1) {
											action+='<a title="Inactivate" class="success blockUnblock" href="" id="success-'+data.category_id+'-tb_category-category_id-status"><button class="btn btn-outline-success btn-xs m-l-5" type="button" title="Inactivate">Inactivate</button></a>';
										}
										else{
											action+='<a class="danger blockUnblock" href="" id="danger-'+data.category_id+'-tb_category-category_id-status"><button class="btn btn-outline-danger btn-xs m-l-5" type="button" title="Activate">Activate</button></a>'; 
										} 
										return action;
									}
								}],								
							});												
								dataTable.on('page.dt', function() {
								$('html, body').animate({
									scrollTop: $(".dataTables_wrapper").offset().top-50						   
									}, 'slow');						
									});	
							
						<?php } ?>
	</script>
</body>

</html>