 <div class="content-wrap">
<div class="container-fluid">
	<div class="row">
	<!-- Zero Configuration  Starts-->	
		<div class="col-sm-12">
			<div class="card">
			  <div class="card-body">
			  <h4 class="card-title"><?php if(isset($banner_title2)) echo $banner_title2;?>
			  <a href="javascript:void(0);" data-href="<?php echo base_url().admin.'/add-category' ?>" class="openPopUpAddCategory"><button class="btn btn-primary btn-sm btn-float" style="float:right; margin-bottom:10px;">Add Category</button></a>
			</h4>
				<div class="dt-ext table-responsive">
				  <table class="display" id="categoryList">
					<thead>
					  <tr>
						<th>#</th>
						<th>Category Name</th>						
						<th>Category Icon</th>						
						<th>Display Order</th>
						<th>Creation Date</th>
						<th>Status</th>
						<th>Action</th>
					  </tr>
					</thead>
					</table>
				</div>
					<div id="msg"></div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>


<div class="modal fade" id="addcategoryModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal_right_side" role="document">
	<div class="modal-content col-12 col-md-8">
	  <div class="modal-header">
		<h5 class="modal-title cat_title">Add Category</h5>
		<button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	  </div>
	  <div class="modal-body cat_body">
	</div>
	</div>
  </div>
</div>

<div class="modal fade" id="viewcategoryModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal_right_side" role="document">
	<div class="modal-content col-12 col-md-8">
	  <div class="modal-header">
		<h5 class="modal-title">View Category</h5>
		<button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	  </div>
	  <div class="modal-body cat_view_body">
	  
	  </div>
	</div>
  </div>
</div>