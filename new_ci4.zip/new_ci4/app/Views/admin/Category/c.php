	<div class="container-fluid">
	<div class="row">
	
		<div class="col-12">
			<div class="card shadow-0 border">
				<div class="card-header align">
					<h5>Category Details</h5>
				</div>
				<div class="card-body packaging-card">
					<div class="table-responsive">
						<table class="table table-striped hght" id="basic-1">
							<thead>						
								<tr>					
									<th>Name</th>
									<th>Details</th> 		
									<th>Name</th>
									<th>Details</th> 			
								</tr>
							</thead>
							<tbody>		
								<tr>	
									<td>Category Name</td>
									<td><?php if(isset($category_name)){ echo $category_name; } ?></td>	
									<td>Banner Image</td>									
									 <td><?php if(isset($category_icon) && $category_icon != '') { ?><a href="<?php echo base_url().'/uploads/category/'.$category_icon;?>" target="_blank"><img src="<?php echo base_url().'/uploads/category/'.$category_icon;?>" width="100"></a><?php } else { echo 'N/A'; } ?></td>	
								</tr>
								<tr>	
									<td>Display Order</td>
									<td><?php if(isset($display_order)){ echo $display_order; } ?></td>						
									<td>Page Title</td>				
									<td><?php if(isset($page_title)){ echo $page_title; } ?></td>				
								</tr>
								 
								<tr>	
									<td>Creation date</td>
									<td><?php if(isset($insert_date)){ echo $insert_date; } ?></td>	
									<td></td>
									<td></td>
								</tr>
							</tbody>
						</table>	
					</div>
				</div>
			</div>
		</div>
	</div>
</div>