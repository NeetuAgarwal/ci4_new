<form class="theme-form" id="categoryFrm" name="categoryFrm" method="post" >		
		<input type="hidden" name="old_icon" id="old_icon" value="<?php if(isset($cat_image)) { echo $cat_image; } ?>">
		<input type="hidden" name="category_id" value="<?php if(isset($category_id)) { echo $category_id; } ?>">
				<input type="hidden" name="old_cat_name" value="<?php if(isset($category_name)) { echo $category_name; } ?>">
				<input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>"  id="csrftoken"/>
			<div class="row"> 
				<div class="form-group col-6">
					<label>Category Name</label>
					<input type="text" name="cat_name" id="cat_name" class="form-control" placeholder="Enter Category Name" value="<?php if(isset($category_name)) { echo $category_name; } ?>"/>
				</div>							 
				<div class="form-group col-6">
					<label>Display Order Number</label>
					<input type="number" name="display_order" id="display_order" min='1' class="form-control" placeholder="Enter Display Order" value="<?php if(isset($display_order)) { echo $display_order; } ?>"/>
				</div>
				
				<div class="form-group col-6">
					<label>Page Title</label>
					<input type="text" name="page_title" id="page_title" class="form-control" placeholder="Enter Page Title" value="<?php if(isset($page_title)) { echo $page_title; } ?>"/>
				</div>				 
			
				<div class="form-group col-6">
					<label for="">Category Image<span class="Img_ext">(Allow Only.jpeg,.jpg,.png) (Size = 256 x 256)</span></label>
					<input class="form-control" name="category_img" id="category_img" type="file" onchange="return validateImageExtensionOther(this.value,1)" />
				</div>
				
				<?php if(isset($cat_image)) { ?>
				<div class="form-group col-6">
				<img src="<?php echo base_url(); ?>/uploads/category/<?php echo $cat_image; ?>" height="40px" width="40px">
				</div>
				
				<?php } ?>
				
				
				<div class="form-group col-12">
					<button type="submit" class="btn btn-primary waves-light m-t-10" id="submitBtn" name="submitBtn">Submit</button>
					<button type="reset" class="btn btn-danger waves-light m-t-10">Reset</button>
				
				</div>
			</div>
			<div class="form-group">
				<div id="errormsg"></div>
			</div>
		</form>