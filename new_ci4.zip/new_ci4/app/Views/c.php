 <div class="content-wrap">
<div class="container">
<div class="row">
<div class="col-12">
<div class="card">
<div class="card-body">
	<form class="theme-form" id="catFrm" name="catFrm" method="post">
		<div class="row">
			<input type="hidden" name = "cat_id" id="cat_id" value="<?php if(isset($cat_id)) { echo $cat_id; } ?>">
			<div class="form-group col-md-6">
				<label>Category Name</label>
				<input type="test" name="category_name" id="category_name" class="form-control" placeholder="Enter Category Name" value="<?php if(isset($category_name)) echo $category_name; ?>">
			</div>
			<div class="form-group col-md-12">
				<button type="submit" class="btn btn-primary waves-light m-t-10" id="submitBtn" name="submitBtn"> Submit</button>
				<button type="reset" class="btn btn-danger waves-light m-t-10" data-original-title="" title="">Reset</button>
			</div> 
			<div class="form-group col-md-12">
				<div id="errormsg"></div>
			</div>
		</div>
		
	</form>
</div>
</div>
</div>
</div>
<div class="row">
	<div class="col-12">
		<div class="card">
			<div class="card-title">
				<h4>Category Table</h4>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table">
						<thead>
							<tr>
								<th>#</th>
								<th>Name</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							 <?php if(isset($catData)) { $i = 1; foreach($catData as $rs) {  ?>
							 <tr>
								<td><?php echo $i; ?></td>
								<td><?php echo $rs->category_name; ?></td>
								<td><a href="<?php echo base_url(admin.'/category-management/'.$rs->cat_id); ?>"><span class="jsgrid-button jsgrid-edit-button ti-pencil" type="button" title="Edit"></span></td>
							 </tr>
							 <?php } } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

   
</div>
 