 <div class="unix-login">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="index.html"><span>Admin</span></a>
                        </div>
                        <div class="login-form">
                            <h4>Administratior Login</h4>
                            <form id="loginFrm" method="post">
                                <div class="form-group">
                                    <label>Email address</label>
                                    <input type="text" id="email" name="email" class="form-control" placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" name= "password" id="password" class="form-control" placeholder="Password">
                                </div>
                                <button type="submit" class="btn btn-primary btn-flat m-b-30 m-t-30">Sign in</button>
                                <div class="register-link m-t-15 text-center">
                                    <p>Don't have account ? <a href="#"> Sign Up Here</a></p>
                                </div>
								<div class="form-group">
									<div id="error"></div>
								</div>
                            </form>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>
