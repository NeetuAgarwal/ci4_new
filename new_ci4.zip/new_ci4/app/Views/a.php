<div class="container">
	<div class="row">
	<?php  echo $hello;  ?>
	</div>
</div>