<?php namespace App\Libraries;

class Customlib
{
	 
	function error($msg)
	{
		return "<p class='alert alert-danger'><strong>Error : </strong> ".$msg."</p>";
	}

	function success($msg)
	{
		return "<p class='alert alert-success'>".$msg."</p>";
	}
	
	 
}