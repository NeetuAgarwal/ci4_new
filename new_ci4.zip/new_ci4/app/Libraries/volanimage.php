<?php namespace App\Libraries;

class Volanimage
{
	 
		/* $this->insert_date = date('Y-m-d H:i:s'); */
 
  public function upload_image($path,$file)
  {
	  	$newfilename = rand() * time();
		if ((!empty($file)) && ($file->isValid())) 
		{
			$filename = strtolower(basename($file->getName()));
			$ext = substr($filename, strrpos($filename, '.') + 1);
			$ext = strtolower($ext);
			$filename=$newfilename.'.'.$ext;
			$ext = "." . $ext;
			$newname = $filename;
			if ($file->move($path,$newname) or die('file not exits')) {
				 
			}
				return  $filename;
			 
		}
  }
} 