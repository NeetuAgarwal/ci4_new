<?php
namespace App\Models;
use CodeIgniter\Model;

class Adminamodel extends Model
{
	protected $table = "tb_new";

	public function find_all()
	{
		$data = $this->findAll();
		echo "<pre>";
		print_r($data);die;
	}

	public function select_all_data($tb)
	{
		return $this->db->table($tb)->get()->getResult();
		 
		
	}
	public function data_search($sql)
	{
		
		$query = $this->db->query($sql);		
		if($query->getNumRows()>0)
        {
            return $query->getResult();  
        }
        else
        {
            return null;
        }
	}
	public function data_search_count($sql)
    {
		$query = $this->db->query($sql);
        return $query->getNumRows();
    } 
	public function select_where_data($tb,$where)
	{
		return $this->db->table($tb)->getWhere($where)->getResult();
		 
		
	}
	public function insertData($tb,$data)
	{
		$this->db->table($tb)->insert($data);
	}
	public function updateData($tb,$data,$where)
	{
		 
		 
		$this->db->table($tb)->update($data,$where);
		
	}
	
}