<?php
namespace App\Controllers;
use App\Models\Adminamodel; 

class Blockdatacontroller extends BaseController
{
	public function blockDataFunction() 
		{
			 
			$id = $this->request->getVar('id');
			$table = $this->request->getVar('table');
			$id_name = $this->request->getVar('table_id');
			$status_name = $this->request->getVar('status_name');
			
			
			$where=array($id_name => $id);
			 $result = $this->adminModel->select_where_data($table,$where);
			$status='';
			foreach($result as $register)
			{
				$status=$register->$status_name;	
			}
			if($status=='1')
			{
				$status='0';				
				$msg='Inactive';
			}
			else
			{
				$status='1';				
				$msg='Active';
			}
			$data=array($status_name=>$status);
			$this->adminModel->updateData($table,$data,$where);
			echo  "<p class='alert alert-success'>".$msg." Successfully</p>";
			die;
		}
}