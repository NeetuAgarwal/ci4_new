<?php

namespace App\Controllers;
use App\Models\Adminamodel;
use CodeIgniter\RESTful\BaseController;
use Exception;
use Firebase\JWT\JWT; 


// headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=utf8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control");
	

class Categorycontroller extends BaseController
{
	
	private function getKey()
    {
        return "my_application_secret";
    }
	
	public function validateUser()
    {
        $userModel = new UserModel();

        $userdata = $userModel->where("email", $this->request->getVar("email"))->first();

        if (!empty($userdata)) {

            if (password_verify($this->request->getVar("password"), $userdata['password'])) {

                $key = $this->getKey();

                $iat = time();
                $nbf = $iat + 10;
                $exp = $iat + 3600;

                $payload = array(
                    "iss" => "The_claim",
                    "aud" => "The_Aud",
                    "iat" => $iat,
                    "nbf" => $nbf,
                    "exp" => $exp,
                    "data" => $userdata,
                );

                $token = JWT::encode($payload, $key);

                $response = [
                    'status' => 200,
                    'error' => FALSE,
                    'messages' => 'User logged In successfully',
                    'token' => $token
                ];
                return $this->respondCreated($response);
            } else {

                $response = [
                    'status' => 500,
                    'error' => TRUE,
                    'messages' => 'Incorrect details'
                ];
                return $this->respondCreated($response);
            }
        } else {
            $response = [
                'status' => 500,
                'error' => TRUE,
                'messages' => 'User not found'
            ];
            return $this->respondCreated($response);
        }
    }

/* 	public function jwtToken()
	{
		require_once('vendor/autoload.php');

		$secretKey  = 'bGS6lzFqvvSQ8ALbOxatm7/Vk7mLQyzqaS34Q4oR1ew=';
		$issuedAt   = time();
		$expire     = $issuedAt->modify('+6 minutes')->getTimestamp();      // Add 60 seconds
		$serverName = "your.domain.name";
		$username   = "username";                                           // Retrieved from filtered POST data

		$data = [
			'iat'  => $issuedAt,         // Issued at: time when the token was generated
			'iss'  => $serverName,       // Issuer
			'nbf'  => $issuedAt,         // Not before
			'exp'  => $expire,           // Expire
			'userName' => $username,     // User name
		];


		 echo JWT::encode(
				$data,
				$secretKey,
				'HS512'
			);
			die;	
	} */
	
	public function categoryManagement()
	{
		if($this->session->get('adminlogin')!= 0)
		{
			/* $cat_id =  $this->request->uri->getSegment(3);
			$where = array("cat_id" => $cat_id);
			$res = $this->adminModel->select_where_data($this->tb2,$where);
			
			if(count($res)>0)
			{
				foreach($res as $rs)
				{
					$this->data['cat_id'] = $rs->cat_id;
					$this->data['category_name'] = $rs->category_name;
				}
			}
			$this->data['catData'] = $this->adminModel->select_all_data($this->tb2); */
			
				$catData = $this->adminModel->find_all();
				
				
			
			$this->data['categoryListTableFlag'] = 1;
			$this->middle = 'admin/Category/a';
			$this->layout();
		}
		else
		{
			return redirect()->to(admin);
		}
	
	}
	public function addCategory()
	{
		return View('admin/Category/b');
	}
	public function submitCategory()
	{ 
		$old_icon = trim($this->request->getVar('old_icon'));
		$category_id = trim($this->request->getVar('category_id'));
		$old_cat_name = trim($this->request->getVar('old_cat_name'));
		$cat_name = trim($this->request->getVar('cat_name'));
		$display_order = trim($this->request->getVar('display_order'));
		$page_title = trim($this->request->getVar('page_title'));
		$file = $this->request->getFile('category_img');
		$category_img='';
		$path2 = 'uploads/category/';
		if($file->getName()!="")
		{
			$category_img=$this->volanimage->upload_image($path2,$file);
		}else{
			$category_img = $old_icon;
		}
		 
		 
		$categoryData = array(
		'category_name' => ucwords($cat_name),
		'display_order' => $display_order,
		'page_title' => ucwords($page_title),
		'cat_image' => $category_img,
		'insert_date' => $this->insert_date
		);
		if($category_id == "")
		{ 
			$this->adminModel->insertData($this->tb2,$categoryData);
		 
			$data['msg'] = $this->customlib->success("Successfully Addedd!!");
		}
		else
		{ 
			$where = array("category_id" => $category_id);
			$this->adminModel->updateData($this->tb2,$categoryData,$where);
			$data['msg'] = $this->customlib->success("Successfully Updated!!");
		}
		$data['csrf']=csrf_hash();
		
		$data['status'] = "success";
		
		echo json_encode($data);
	}
	
	public function categoryListGridData()
	{
		$columns = array( 
			0 => 'category_id',
			1 => 'category_name',
			2 => 'cat_image',
			3 => 'display_order',
			4 => 'insert_date',
			5 => 'status',
			6 => 'category_id'
		);
		
		$limit = $this->request->getVar('length');
		$start = $this->request->getVar('start');
		$order = $columns[$this->request->getVar('order')[0]['column']];
		$dir = $this->request->getVar('order')[0]['dir'];
		
		$sql = "SELECT category_id,category_name,cat_image,display_order,status,date_format(insert_date,'%d %b %Y %r') as insert_date ";
		$sql.=" FROM ".$this->tb2." WHERE 1=1";
		
		$totalData = $this->adminModel->data_search_count($sql);	
		 
		$totalFiltered = $totalData;
		
		if(!empty($this->request->getVar('search')['value'])){
			$search = $this->request->getVar('search')['value'];
			$sql.= " AND (category_name LIKE '".$search."%' ";
			$sql.=" OR insert_date LIKE '".$search."%' )";
				
			$tb_data =  $this->adminModel->data_search($sql);
			$totalFiltered = $this->adminModel->data_search_count($sql);
		}else{
			$sql.=" ORDER BY ". $order."   ".$dir."  LIMIT ".$start." ,".$limit."   ";
			$tb_data =  $this->adminModel->data_search($sql);
		}
		
		$i=$start+1;
		$data = array();
		if(!empty($tb_data))
		{
			foreach($tb_data as $rs )
			{
				$nestedData = array();
				
				$nestedData['#'] = $i;
				$nestedData['category_name'] = $rs->category_name;
				$nestedData['category_icon'] ='<a href="'.base_url().'/uploads/category/'.$rs->cat_image.'" target="_blank"><img class="icons" src="'.base_url().'/uploads/category/'.$rs->cat_image.'" height="40px" width="40px"></a>';
				$nestedData['insert_date'] = $rs->insert_date;
				$nestedData['display_order'] = $rs->display_order;
				$nestedData['status'] = $rs->status;
				$nestedData['category_id'] = $rs->category_id;
				if($rs->status==1)
				{
					$nestedData['display_status'] = '<div id="status_show'.$rs->category_id.'"><badge class="badge badge-success">Active</badge></div>';
				}
				else
				{
					$nestedData['display_status'] = '<div id="status_show'.$rs->category_id.'"><badge class="badge badge-danger">Inactive</badge></div>';
				}
				 
				 
				$data[] = $nestedData;
				$i++;
			}
		}
		$json_data = array(
					"draw"            => intval($this->request->getVar('draw')),  
					"recordsTotal"    => intval($totalData),  
					"recordsFiltered" => intval($totalFiltered), 
					"data"            => $data   
					);
			
		echo json_encode($json_data); 
	}
	public function editCategory()
	{
	    $cat_id =  $this->request->uri->getSegment(3);
		$where = array("category_id" => $cat_id);
		$res = $this->adminModel->select_where_data($this->tb2,$where);
		foreach($res as $rs)
		{
			$this->data['category_id'] = $rs->category_id;
			$this->data['category_name'] = $rs->category_name;
			$this->data['display_order'] = $rs->display_order;
			$this->data['page_title'] = $rs->page_title;
			$this->data['cat_image'] = $rs->cat_image;
		}
		 
		echo View('admin/Category/b',$this->data);
		
	}
	public function viewCategory()
	{
	    $cat_id =  $this->request->uri->getSegment(3);
		$where = array("category_id" => $cat_id);
		$res = $this->adminModel->select_where_data($this->tb2,$where);
		foreach($res as $rs)
		{
			$this->data['category_id'] = $rs->category_id;
			$this->data['category_name'] = $rs->category_name;
			$this->data['display_order'] = $rs->display_order;
			$this->data['page_title'] = $rs->page_title;
			$this->data['cat_image'] = $rs->cat_image;
			$this->data['insert_date'] = date('Y-m-d',strtotime($rs->insert_date));
		}
		
		 
		echo View('admin/Category/c',$this->data);
		
	}
}