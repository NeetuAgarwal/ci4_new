<?php

namespace App\Controllers;
use App\Models\Adminamodel; 

class Logincontroller extends BaseController
{
	public function login()
	{
	/* 	$this->session->remove('adminlogin'); */
		if($this->session->get('adminlogin') == 0)
		{
			$this->data['bg_color'] = "bg-primary";
			$this->middle = 'b';
			$this->loginlayout();
		}
		else
		{
			return redirect()->to(admin.'/dashboard');
		}
	
	}
	public function submitLogin()
	{
		 $email = $this->request->getVar("email");
		 $pass = $this->request->getVar("password");
		$data = $this->adminModel->select_all_data($this->tb1);
		if(count($data)>0)
		{
			foreach($data as $rs)
			{
				$password = $rs->password;
			}
		}
		
		$password = $this->decType($password);
	 
		if($pass == $password)
		{
			$this->session->set('adminlogin',1);
			$data['status'] = "success";
			$data['msg'] = "<p class='alert alert-success'>Succesfully Login...Redirecting.</p>";
			//return  redirect->to('/dashboard');
		}
		else 
		{
			$data['msg'] = "<p class='alert alert-danger'>Invalid Login Details</p>";
			echo json_encode($data);die;
		}
		echo json_encode($data);
	}
	public function logout()
	{ 
		$this->session->remove("adminlogin");
		$myurl = base_url().'/';
		return redirect()->to($myurl);
		 
	}
 
}
