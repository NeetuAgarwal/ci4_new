<?php

namespace App\Controllers;

class Dashboardcontroller extends BaseController
{
	  
     
	
	public function index()
	{
		$this->data['bg_color'] = "bg-primary";
		$this->middle = 'b';
		$this->loginlayout();
	}
	public function dashboard()
	{
		
		if($this->session->get('adminlogin')!=0)
		{
			 
			$this->data['hello'] = "neetu";
			$this->middle = 'a';
			$this->layout();
		}
		else 
		{
			return redirect()->to('/');
		}
	
	}
	public function demo()
	{
		echo "asdasdasd";
	}
}
