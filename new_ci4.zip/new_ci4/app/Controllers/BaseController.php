<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;
use App\Libraries\volanimage; 
use App\Libraries\customlib; 
/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 */

class BaseController extends Controller
{
	/**
	 * An array of helpers to be loaded automatically upon
	 * class instantiation. These helpers will be available
	 * to all other controllers that extend BaseController.
	 *
	 * @var array
	 */
	protected $helpers = [];
	var $data = array();

	/**
	 * Constructor.
	 *
	 * @param RequestInterface  $request
	 * @param ResponseInterface $response
	 * @param LoggerInterface   $logger
	 */
	public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
	{
		// Do Not Edit This Line
		parent::initController($request, $response, $logger);

		//--------------------------------------------------------------------
		// Preload any models, libraries, etc, here.
		//--------------------------------------------------------------------
		// E.g.: $this->session = \Config\Services::session();
		 $this->adminModel = new \App\Models\Adminamodel();
		 $this->volanimage = new volanimage();
		 $this->customlib = new customlib();
		$this->cur_date = date("Y-m-d");
		$this->insert_date = date("Y-m-d H:i:s");
		 $this->session= session();
		 $this->tb1 = 'tb_login';
		 $this->tb2 = 'tb_category';
		 $this->security = \Config\Services::security();
		 $this->encrypter = \Config\Services::encrypter();
		 
	}
	public function layout() 
	{
		
		$data['header']=view('admin_layout/header',$this->data);
		$data['middle']=view($this->middle,$this->data);
		$data['footer']=view('admin_layout/footer');
		echo view('admin_layout/index',$data);
	}
	public function loginlayout() 
	{
		$data['middle']=view($this->middle,$this->data);
		echo view('admin_layout/index',$data);
	}
	public function encType($data)
	{
		 
		return base64_encode($this->encrypter->encrypt($data));
	}
	public function decType($data)
	{
		return $this->encrypter->decrypt(base64_decode($data));
	}
	
}
